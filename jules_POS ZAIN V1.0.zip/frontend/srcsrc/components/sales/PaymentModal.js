import React, { useState } from 'react';
import { Frame, Button } from '@arwes/core';
import { Text } from '@arwes/react';

const PaymentModal = ({ totalAmount, onSave }) => {
  const [amountPaid, setAmountPaid] = useState(0);

  const handleSave = () => {
    onSave(amountPaid);
  };

  return (
    <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 1000 }}>
      <Frame>
        <div style={{ padding: 20, width: 400 }}>
          <Text as="h2">Payment</Text>
          <p>Total Amount: {totalAmount}</p>
          <div>
            <label>Amount Paid:</label>
            <input
              type="number"
              value={amountPaid}
              onChange={(e) => setAmountPaid(e.target.value)}
            />
          </div>
          <p>Change: {amountPaid - totalAmount}</p>
          <div style={{ marginTop: 20 }}>
            <Button onClick={handleSave}>
              <Text>Save</Text>
            </Button>
          </div>
        </div>
      </Frame>
    </div>
  );
};

export default PaymentModal;
