import React, { useState, useEffect } from 'react';
import { ArwesThemeProvider, StylesBaseline, Button } from '@arwes/core';
import { AnimatorGeneralProvider } from '@arwes/animation';
import { BleepsProvider } from '@arwes/sounds';
import { Text } from '@arwes/react';
import CompanyInfo from './components/settings/CompanyInfo';
import Branches from './components/settings/Branches';
import Currencies from './components/settings/Currencies';
import FiscalPeriods from './components/settings/FiscalPeriods';
import InvoiceDesigner from './components/reporting/InvoiceDesigner';
import ReportBuilder from './components/reporting/ReportBuilder';
import AdvancedPOS from './components/sales/AdvancedPOS';
import Login from './components/auth/Login';

const App = () => {
  const [authTokens, setAuthTokens] = useState(() => localStorage.getItem('authTokens') ? JSON.parse(localStorage.getItem('authTokens')) : null);

  const setToken = (data) => {
    setAuthTokens(data);
  };

  if (!authTokens) {
    return <Login setToken={setToken} />;
  }

  const [activeTab, setActiveTab] = useState('pos');

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'pos':
        return <AdvancedPOS />;
      case 'company-info':
        return <CompanyInfo />;
      case 'branches':
        return <Branches />;
      case 'currencies':
        return <Currencies />;
      case 'fiscal-periods':
        return <FiscalPeriods />;
      case 'invoice-designer':
        return <InvoiceDesigner />;
      case 'report-builder':
        return <ReportBuilder />;
      default:
        return <AdvancedPOS />;
    }
  };

  return (
    <ArwesThemeProvider>
      <StylesBaseline />
      <BleepsProvider>
        <AnimatorGeneralProvider>
          <div style={{ padding: 20 }}>
            <Text as="h1">Zain POS V1.0</Text>
            <div>
              <Button onClick={() => setActiveTab('pos')}>
                <Text>POS</Text>
              </Button>
              <Button onClick={() => setActiveTab('company-info')}>
                <Text>Company Info</Text>
              </Button>
              <Button onClick={() => setActiveTab('branches')}>
                <Text>Branches</Text>
              </Button>
              <Button onClick={() => setActiveTab('currencies')}>
                <Text>Currencies</Text>
              </Button>
              <Button onClick={() => setActiveTab('fiscal-periods')}>
                <Text>Fiscal Periods</Text>
              </Button>
              <Button onClick={() => setActiveTab('invoice-designer')}>
                <Text>Invoice Designer</Text>
              </Button>
              <Button onClick={() => setActiveTab('report-builder')}>
                <Text>Report Builder</Text>
              </Button>
            </div>
            <div style={{ marginTop: 20 }}>
              {renderActiveTab()}
            </div>
          </div>
        </AnimatorGeneralProvider>
      </BleepsProvider>
    </ArwesThemeProvider>
  );
};

export default App;
