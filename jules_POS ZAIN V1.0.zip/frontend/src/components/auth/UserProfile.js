import React, { useState, useEffect } from 'react';
import api from '../api';

const UserProfile = () => {
    const [profile, setProfile] = useState(null);

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const response = await api.get('/users/profile/');
                setProfile(response.data);
            } catch (error) {
                console.error('Error fetching user profile:', error);
            }
        };
        fetchProfile();
    }, []);

    if (!profile) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <p>User: {profile.user.username}</p>
            <p>Branch: {profile.branch.name}</p>
            <p>Warehouse: {profile.warehouse.name}</p>
            <p>Cash Register: {profile.cash_register.name}</p>
        </div>
    );
};

export default UserProfile;
