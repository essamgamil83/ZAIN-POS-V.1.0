import React from 'react';
import { Frame, Line } from '@arwes/core';
import { Text } from '@arwes/react';

const Currencies = () => {
  return (
    <div>
      <Frame>
        <Text as="h2">Currencies</Text>
        <Line />
        <p>Manage currencies here.</p>
      </Frame>
    </div>
  );
};

export default Currencies;
