import React from 'react';
import { Frame, Line } from '@arwes/core';
import { Text } from '@arwes/react';

const FiscalPeriods = () => {
  return (
    <div>
      <Frame>
        <Text as="h2">Fiscal Periods</Text>
        <Line />
        <p>Manage fiscal periods here.</p>
      </Frame>
    </div>
  );
};

export default FiscalPeriods;
