import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Frame, Line, Button, Table } from '@arwes/core';
import { Text } from '@arwes/react';

const AdvancedPOS = () => {
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [cart, setCart] = useState([]);
  const [totalAmount, setTotalAmount] = useState(0);

  useEffect(() => {
    // Fetch customers and products
    const fetchData = async () => {
      try {
        const [customersRes, productsRes] = await Promise.all([
          axios.get('/api/customers/customers/'),
          axios.get('/api/stock/products/')
        ]);
        setCustomers(customersRes.data);
        setProducts(productsRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  const handleAddToCart = (product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.product.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prevCart, { product, quantity: 1, price: product.price }];
      }
    });
  };
  
    useEffect(() => {
    const total = cart.reduce((sum, item) => sum + item.quantity * item.price, 0);
    setTotalAmount(total);
  }, [cart]);

  const handleSaveInvoice = async () => {
    if (!selectedCustomer || cart.length === 0) {
      alert('Please select a customer and add items to the cart.');
      return;
    }

    try {
      await axios.post('/api/sales/invoices/', {
        customer: selectedCustomer,
        total_amount: totalAmount,
        items: cart.map(item => ({
          product: item.product.id,
          quantity: item.quantity,
          price: item.price
        }))
      });
      alert('Invoice saved successfully!');
      setCart([]);
      setSelectedCustomer(null);
    } catch (error) {
      console.error('Error saving invoice:', error);
      alert('Failed to save invoice.');
    }
  };

  return (
    <div>
      <Frame>
        <Text as="h2">Advanced POS</Text>
        <Line />
        
        {/* Customer Selection */}
        <div>
          <label>Customer:</label>
          <select onChange={(e) => setSelectedCustomer(e.target.value)}>
            <option value="">Select a customer</option>
            {customers.map(customer => (
              <option key={customer.id} value={customer.id}>{customer.name}</option>
            ))}
          </select>
        </div>

        {/* Product Selection */}
        <div style={{marginTop: '20px'}}>
          <label>Add Product:</label>
          <select onChange={(e) => handleAddToCart(products.find(p => p.id === parseInt(e.target.value)))}>
            <option value="">Select a product</option>
            {products.map(product => (
              <option key={product.id} value={product.id}>{product.name}</option>
            ))}
          </select>
        </div>
        
        {/* Cart */}
        <div style={{marginTop: '20px'}}>
            <Table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    {cart.map((item, index) => (
                        <tr key={index}>
                            <td>{item.product.name}</td>
                            <td>{item.quantity}</td>
                            <td>{item.price}</td>
                            <td>{item.quantity * item.price}</td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        </div>

        {/* Total */}
        <div style={{marginTop: '20px'}}>
            <Text>Total: {totalAmount}</Text>
        </div>

        {/* Save Button */}
        <div style={{marginTop: '20px'}}>
            <Button onClick={handleSaveInvoice}>
                <Text>Save Invoice</Text>
            </Button>
        </div>
      </Frame>
    </div>
  );
};

export default AdvancedPOS;
