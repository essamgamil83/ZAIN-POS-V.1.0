from django.db import models
from django.contrib.auth.models import User
from zain_config.models import Branch, Warehouse, CashRegister

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    branch = models.ForeignKey(Branch, on_delete=models.SET_NULL, null=True, blank=True)
    warehouse = models.ForeignKey(Warehouse, on_delete=models.SET_NULL, null=True, blank=True)
    cash_register = models.ForeignKey(CashRegister, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.user.username
