from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import InvoiceTemplateViewSet, ReportViewSet

router = DefaultRouter()
router.register(r'invoice-templates', InvoiceTemplateViewSet)
router.register(r'reports', ReportViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
