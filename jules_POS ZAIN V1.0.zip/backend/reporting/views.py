from rest_framework import viewsets
from .models import InvoiceTemplate, Report
from .serializers import InvoiceTemplateSerializer, ReportSerializer

class InvoiceTemplateViewSet(viewsets.ModelViewSet):
    queryset = InvoiceTemplate.objects.all()
    serializer_class = InvoiceTemplateSerializer

class ReportViewSet(viewsets.ModelViewSet):
    queryset = Report.objects.all()
    serializer_class = ReportSerializer
