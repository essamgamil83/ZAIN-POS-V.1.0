import React, { useState, useEffect, useCallback } from 'react';
import api from '../../api';
import { Frame, Line, Button, Table } from '@arwes/core';
import { Text } from '@arwes/react';
import { useHotkeys } from 'react-hotkeys-hook';
import UserProfile from '../auth/UserProfile';
import PaymentModal from './PaymentModal';
import InvoiceList from './InvoiceList';

const AdvancedPOS = () => {
  // State declarations...
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [filteredCustomers, setFilteredCustomers] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [customerSearch, setCustomerSearch] = useState('');
  const [productSearch, setProductSearch] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedProductIndex, setSelectedProductIndex] = useState(0);
  const [cart, setCart] = useState([]);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  
  // Invoice details state
  const [tax, setTax] = useState(0);
  const [discountValue, setDiscountValue] = useState(0);
  const [discountPercent, setDiscountPercent] = useState(0);
  const [shipping, setShipping] = useState(0);
  
  const [subtotal, setSubtotal] = useState(0);
  const [totalAmount, setTotalAmount] = useState(0);

  // Hotkeys
  useHotkeys('f4', () => setShowPaymentModal(true), { preventDefault: true });
  useHotkeys('f5', () => { 
      setShowPaymentModal(true);
      // Placeholder for printing logic
      console.log("Print command triggered.");
    }, { preventDefault: true });
  useHotkeys('f6', () => { console.log('Opening cash drawer...'); }, { preventDefault: true });
  useHotkeys('+', () => updateQuantity(1), { preventDefault: true });
  useHotkeys('-', () => updateQuantity(-1), { preventDefault: true });

  // Data fetching and filtering effects...
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [customersRes, productsRes] = await Promise.all([
          api.get('/customers/customers/'),
          api.get('/stock/products/')
        ]);
        setCustomers(customersRes.data);
        setFilteredCustomers(customersRes.data);
        setProducts(productsRes.data);
        setFilteredProducts(productsRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    setFilteredCustomers(
      customers.filter(c => c.name.toLowerCase().includes(customerSearch.toLowerCase()))
    );
  }, [customerSearch, customers]);

  useEffect(() => {
    setFilteredProducts(
      products.filter(p => p.name.toLowerCase().includes(productSearch.toLowerCase()))
    );
  }, [productSearch, products]);

  // Cart and Total calculation
  const calculateTotal = useCallback(() => {
    const currentSubtotal = cart.reduce((sum, item) => sum + item.quantity * item.price, 0);
    setSubtotal(currentSubtotal);
    
    const discountFromPercent = currentSubtotal * (discountPercent / 100);
    const totalDiscount = discountFromPercent + parseFloat(discountValue);
    const taxAmount = (currentSubtotal - totalDiscount) * (tax / 100);
    const finalTotal = currentSubtotal - totalDiscount + taxAmount + parseFloat(shipping);
    
    setTotalAmount(finalTotal);
  }, [cart, tax, discountValue, discountPercent, shipping]);

  useEffect(() => {
    calculateTotal();
  }, [calculateTotal]);

  const handleAddToCart = (product) => {
    // ... same as before
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.product.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      } else {
        return [...prevCart, { product, quantity: 1, price: product.price }];
      }
    });
    setProductSearch('');
  };

  const updateQuantity = (amount) => {
    // ... same as before
      setCart(prevCart =>
          prevCart.map((item, index) =>
              index === selectedProductIndex ? { ...item, quantity: Math.max(1, item.quantity + amount) } : item
          )
      );
  };
  
  const handleSelectInvoice = async (invoiceId) => {
    try {
        const response = await api.get(`/sales/invoices/${invoiceId}/`);
        const invoice = response.data;
        
        setSelectedCustomer(invoice.customer);
        setTax(invoice.tax_percentage);
        setDiscountPercent(invoice.discount_percentage);
        setDiscountValue(invoice.discount_amount);
        setShipping(invoice.shipping);
        
        const loadedCart = invoice.items.map(item => ({
            product: products.find(p => p.id === item.product),
            quantity: item.quantity,
            price: item.price
        }));
        setCart(loadedCart);
        
    } catch (error) {
        console.error("Error fetching invoice details:", error);
    }
  };


  const handleSaveInvoice = async (amountPaid) => {
    if (!selectedCustomer || cart.length === 0) {
      alert('Please select a customer and add items to the cart.');
      return;
    }
    // ... save logic to be updated with new fields
    console.log("Invoice saved with amount paid:", amountPaid);
    setShowPaymentModal(false);
    // Reset state
    setCart([]);
    setSelectedCustomer(null);
    setTax(0);
    setDiscountPercent(0);
    setDiscountValue(0);
    setShipping(0);
  };

  return (
    <div>
      {showPaymentModal && <PaymentModal totalAmount={totalAmount} onSave={handleSaveInvoice}/>}
      <UserProfile />
      <Frame>
        <Text as="h2">Advanced POS</Text>
        <Line />
        
        <div style={{display: 'flex', gap: '20px'}}>
            <div style={{flex: 1}}>
                {/* Customer and Product Search */}
                {/* ... same as before ... */}
                 {/* Customer Selection */}
                <div>
                  <label>Customer:</label>
                  <input 
                    type="text"
                    placeholder="Search Customers..."
                    value={customerSearch}
                    onChange={e => setCustomerSearch(e.target.value)}
                  />
                  <select onChange={(e) => setSelectedCustomer(e.target.value)} value={selectedCustomer || ''}>
                    <option value="">Select a customer</option>
                    {filteredCustomers.map(customer => (
                      <option key={customer.id} value={customer.id}>{customer.name}</option>
                    ))}
                  </select>
                </div>

                {/* Product Selection */}
                <div style={{marginTop: '20px'}}>
                  <label>Add Product:</label>
                   <input 
                    type="text"
                    placeholder="Search Products..."
                    value={productSearch}
                    onChange={e => setProductSearch(e.target.value)}
                  />
                  <div>
                    {productSearch && filteredProducts.map(product => (
                      <div key={product.id} onClick={() => handleAddToCart(product)} style={{cursor: 'pointer', padding: '5px', borderBottom: '1px solid #555'}}>
                        {product.name}
                      </div>
                    ))}
                  </div>
                </div>
                {/* Cart Table */}
                <div style={{marginTop: '20px'}}>
                    <Table>
                        {/* ... table headers ... */}
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            {cart.map((item, index) => (
                                <tr key={index} onClick={() => setSelectedProductIndex(index)}
                                    style={{backgroundColor: index === selectedProductIndex ? 'hsl(180, 75%, 30%)' : 'transparent', cursor: 'pointer'}}>
                                    <td>{item.product.name}</td>
                                    <td>{item.quantity}</td>
                                    <td>{item.price}</td>
                                    <td>{(item.quantity * item.price).toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </div>
            </div>

            <div style={{width: '300px'}}>
                 <InvoiceList onSelectInvoice={handleSelectInvoice} />
                {/* Invoice Details */}
                <Frame>
                    <Text as="h3">Invoice Details</Text>
                    <Line />
                    <div>
                        <label>Tax (%):</label>
                        <input type="number" value={tax} onChange={e => setTax(parseFloat(e.target.value) || 0)} />
                    </div>
                    <div style={{marginTop: '10px'}}>
                        <label>Discount (%):</label>
                        <input type="number" value={discountPercent} onChange={e => setDiscountPercent(parseFloat(e.target.value) || 0)} />
                    </div>
                    <div style={{marginTop: '10px'}}>
                        <label>Discount (Value):</label>
                        <input type="number" value={discountValue} onChange={e => setDiscountValue(parseFloat(e.target.value) || 0)} />
                    </div>
                    <div style={{marginTop: '10px'}}>
                        <label>Shipping:</label>
                        <input type="number" value={shipping} onChange={e => setShipping(parseFloat(e.target.value) || 0)} />
                    </div>
                    <hr />
                    <div style={{marginTop: '20px', textAlign: 'right'}}>
                        <Text>Subtotal: {subtotal.toFixed(2)}</Text>
                        <Text as="h3">Total: {totalAmount.toFixed(2)}</Text>
                    </div>
                </Frame>
                 <div style={{marginTop: '20px'}}>
                    <Button block onClick={() => setShowPaymentModal(true)}>
                        <Text>Save Invoice (F4)</Text>
                    </Button>
                </div>
            </div>
        </div>
      </Frame>
    </div>
  );
};

export default AdvancedPOS;
