from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CompanyInfoViewSet, BranchViewSet, CurrencyViewSet, FiscalPeriodViewSet

router = DefaultRouter()
router.register(r'company-info', CompanyInfoViewSet)
router.register(r'branches', BranchViewSet)
router.register(r'currencies', CurrencyViewSet)
router.register(r'fiscal-periods', FiscalPeriodViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
