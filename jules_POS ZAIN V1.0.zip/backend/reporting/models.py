from django.db import models

class InvoiceTemplate(models.Model):
    name = models.CharField(max_length=255)
    content = models.JSONField()
    is_default = models.BooleanField(default=False)

    def __str__(self):
        return self.name

class Report(models.Model):
    name = models.CharField(max_length=255)
    source = models.CharField(max_length=100)
    fields = models.JSONField()
    filters = models.JSONField()
    grouping = models.JSONField(blank=True, null=True)

    def __str__(self):
        return self.name
