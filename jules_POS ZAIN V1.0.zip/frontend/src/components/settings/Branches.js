import React from 'react';
import { Frame, Line } from '@arwes/core';
import { Text } from '@arwes/react';

const Branches = () => {
  return (
    <div>
      <Frame>
        <Text as="h2">Branches</Text>
        <Line />
        <p>Manage branches here.</p>
      </Frame>
    </div>
  );
};

export default Branches;
