import React from 'react';
import { Frame, Line } from '@arwes/core';
import { Text } from '@arwes/react';

const CompanyInfo = () => {
  return (
    <div>
      <Frame>
        <Text as="h2">Company Information</Text>
        <Line />
        <p>Manage company details here.</p>
      </Frame>
    </div>
  );
};

export default CompanyInfo;
