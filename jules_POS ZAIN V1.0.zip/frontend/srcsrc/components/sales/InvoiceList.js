import React, { useState, useEffect } from 'react';
import api from '../../api';
import { Frame, Table, Line } from '@arwes/core';
import { Text } from '@arwes/react';

const InvoiceList = ({ onSelectInvoice }) => {
    const [invoices, setInvoices] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const fetchInvoices = async () => {
            try {
                const response = await api.get('/sales/invoices/', {
                    params: { search: searchTerm }
                });
                setInvoices(response.data);
            } catch (error) {
                console.error('Error fetching invoices:', error);
            }
        };
        fetchInvoices();
    }, [searchTerm]);

    return (
        <Frame>
            <Text as="h3">Previous Invoices</Text>
            <Line />
            <input 
                type="text"
                placeholder="Search by Invoice # or Customer"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
            />
            <div style={{maxHeight: '300px', overflowY: 'auto', marginTop: '10px'}}>
                <Table>
                    <thead>
                        <tr>
                            <th>Invoice #</th>
                            <th>Customer</th>
                            <th>Total</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {invoices.map(invoice => (
                            <tr key={invoice.id} onClick={() => onSelectInvoice(invoice.id)} style={{cursor: 'pointer'}}>
                                <td>{invoice.invoice_number}</td>
                                <td>{invoice.customer_name}</td>
                                <td>{invoice.total_amount}</td>
                                <td>{new Date(invoice.date).toLocaleDateString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            </div>
        </Frame>
    );
};

export default InvoiceList;
