from rest_framework import viewsets
from rest_framework.filters import SearchFilter
from .models import SalesInvoice
from .serializers import SalesInvoiceSerializer

class SalesInvoiceViewSet(viewsets.ModelViewSet):
    queryset = SalesInvoice.objects.all().order_by('-date')
    serializer_class = SalesInvoiceSerializer
    filter_backends = [SearchFilter]
    search_fields = ['invoice_number', 'customer__name']
