import React, { useState } from 'react';
import axios from 'axios';
import { DndContext, closestCenter } from '@dnd-kit/core';
import { arrayMove, SortableContext, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Frame, Line, Button } from '@arwes/core';
import { Text } from '@arwes/react';

const DraggableItem = ({ id, children }) => {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    padding: 10,
    margin: 5,
    border: '1px solid #ddd',
    backgroundColor: '#333'
  };

  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
      {children}
    </div>
  );
};

const InvoiceDesigner = () => {
  const [items, setItems] = useState([]);
  const [templateName, setTemplateName] = useState('');

  const availableItems = [
    { id: 'logo', name: 'Logo' },
    { id: 'company-info', name: 'Company Info' },
    { id: 'item-table', name: 'Item Table' },
  ];

  const handleDragEnd = (event) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
        setItems((items) => {
            const oldIndex = items.findIndex(item => item.id === active.id);
            const newIndex = items.findIndex(item => item.id === over.id);

            if (oldIndex !== -1) {
                return arrayMove(items, oldIndex, newIndex);
            } else {
                const newItem = availableItems.find(item => item.id === active.id);
                return [...items, newItem];
            }
        });
    }
  };

  const handleSave = async () => {
    try {
      await axios.post('/api/reporting/invoice-templates/', {
        name: templateName,
        content: items,
      });
      alert('Template saved successfully!');
    } catch (error) {
      console.error('Error saving template:', error);
      alert('Failed to save template.');
    }
  };

  return (
    <DndContext collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <div>
        <input 
          type="text" 
          value={templateName} 
          onChange={(e) => setTemplateName(e.target.value)} 
          placeholder="Enter template name" 
        />
        <Button onClick={handleSave}>
          <Text>Save Template</Text>
        </Button>
      </div>
      <div style={{ display: 'flex', marginTop: 20 }}>
        <div style={{ width: 200, marginRight: 20 }}>
          <Frame>
            <Text as="h3">Available Items</Text>
            <Line />
            {availableItems.map(item => (
                <DraggableItem key={item.id} id={item.id}>
                    <Text>{item.name}</Text>
                </DraggableItem>
            ))}
          </Frame>
        </div>
        <div style={{ flex: 1 }}>
          <Frame>
            <Text as="h3">Invoice Layout</Text>
            <Line />
            <div style={{ minHeight: 400, border: '1px dashed #ddd', padding: 10 }}>
              <SortableContext items={items.map(i => i.id)} strategy={verticalListSortingStrategy}>
                {items.map(item => (
                  <DraggableItem key={item.id} id={item.id}>
                    <Text>{item.name}</Text>
                  </DraggableItem>
                ))}
              </SortableContext>
            </div>
          </Frame>
        </div>
      </div>
    </DndContext>
  );
};

export default InvoiceDesigner;
