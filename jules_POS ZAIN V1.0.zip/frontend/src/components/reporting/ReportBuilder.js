import React, { useState } from 'react';
import axios from 'axios';
import { Frame, Line, Button } from '@arwes/core';
import { Text } from '@arwes/react';

const ReportBuilder = () => {
  const [reportName, setReportName] = useState('');
  const [dataSource, setDataSource] = useState('');
  const [fields, setFields] = useState([]);

  const availableDataSources = [
    { id: 'sales', name: 'Sales' },
    { id: 'inventory', name: 'Inventory' },
  ];

  const availableFields = {
    sales: ['Date', 'Product', 'Quantity', 'Price'],
    inventory: ['Product', 'Stock Level', 'Location'],
  };

  const handleFieldChange = (field) => {
    setFields(prevFields => 
      prevFields.includes(field) 
        ? prevFields.filter(f => f !== field) 
        : [...prevFields, field]
    );
  };

  const handleSave = async () => {
    try {
      await axios.post('/api/reporting/reports/', {
        name: reportName,
        source: dataSource,
        fields: fields,
        filters: {}, 
        grouping: {} 
      });
      alert('Report saved successfully!');
    } catch (error) {
      console.error('Error saving report:', error);
      alert('Failed to save report.');
    }
  };

  return (
    <div>
      <input 
        type="text" 
        value={reportName} 
        onChange={(e) => setReportName(e.target.value)} 
        placeholder="Enter report name" 
      />
      <select value={dataSource} onChange={(e) => setDataSource(e.target.value)}>
        <option value="">Select Data Source</option>
        {availableDataSources.map(ds => (
          <option key={ds.id} value={ds.id}>{ds.name}</option>
        ))}
      </select>

      {dataSource && (
        <div>
          <h3>Available Fields</h3>
          {availableFields[dataSource].map(field => (
            <div key={field}>
              <input 
                type="checkbox" 
                id={field} 
                value={field} 
                checked={fields.includes(field)}
                onChange={() => handleFieldChange(field)}
              />
              <label htmlFor={field}>{field}</label>
            </div>
          ))}
        </div>
      )}

      <Button onClick={handleSave}>
        <Text>Save Report</Text>
      </Button>
    </div>
  );
};

export default ReportBuilder;
