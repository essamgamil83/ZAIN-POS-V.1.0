from django.apps import AppConfig


class ZainConfigConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "zain_config"
