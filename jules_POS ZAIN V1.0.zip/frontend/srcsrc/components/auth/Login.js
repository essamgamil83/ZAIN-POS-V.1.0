import React, { useState } from 'react';
import axios from 'axios';
import { Frame, Button } from '@arwes/core';
import { Text } from '@arwes/react';

const Login = ({ setToken }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/token/', {
        username,
        password,
      });
      setToken(response.data);
      localStorage.setItem('authTokens', JSON.stringify(response.data));
    } catch (error) {
      console.error('Login failed:', error);
      alert('Login failed!');
    }
  };

  return (
    <div style={{ padding: 20, maxWidth: 400, margin: '0 auto' }}>
      <Frame>
        <form onSubmit={handleSubmit}>
          <Text as="h2">Login</Text>
          <div>
            <label>Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div style={{ marginTop: 20 }}>
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div style={{ marginTop: 20 }}>
            <Button type="submit">
              <Text>Login</Text>
            </Button>
          </div>
        </form>
      </Frame>
    </div>
  );
};

export default Login;
