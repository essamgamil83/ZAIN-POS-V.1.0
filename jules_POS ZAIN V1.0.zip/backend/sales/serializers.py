from rest_framework import serializers
from .models import SalesInvoice, SalesInvoiceItem
from stock_management.models import Product

class SalesInvoiceItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalesInvoiceItem
        fields = ['product', 'quantity', 'price']

class SalesInvoiceSerializer(serializers.ModelSerializer):
    items = SalesInvoiceItemSerializer(many=True, required=False)
    customer_name = serializers.CharField(source='customer.name', read_only=True)

    class Meta:
        model = SalesInvoice
        fields = [
            'id', 'invoice_number', 'customer', 'customer_name', 'date', 'subtotal',
            'tax_percentage', 'tax_amount', 'discount_percentage', 'discount_amount',
            'bonus', 'shipping', 'total_amount', 'user', 'branch', 'warehouse',
            'cash_register', 'items'
        ]
        read_only_fields = ['id', 'invoice_number', 'date', 'customer_name']

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        invoice = SalesInvoice.objects.create(**validated_data)
        for item_data in items_data:
            SalesInvoiceItem.objects.create(invoice=invoice, **item_data)
            
            # Update product quantity
            product = item_data['product']
            product.quantity_available -= item_data['quantity']
            product.save()
            
        # Update customer balance (assuming sales are on credit)
        customer = validated_data['customer']
        customer.balance += validated_data['total_amount']
        customer.save()
        
        return invoice
